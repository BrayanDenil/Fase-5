package sistema_de_tickes;

import Modelos.Tickets;
import Modelos.Estado;
import Modelos.Departamento;
import java.io.*;
import java.net.URL;
import java.util.*;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;

/**
 * FXML Controller class
 *
 * @author denil
 */
public class TicketController implements Initializable {

    @FXML private TextField fldTitulo;
    @FXML private TextArea txtDescripcion;
    @FXML private ComboBox<Departamento> cbxDepartamento;
    @FXML private ComboBox<String> cbxPrioridad;
    @FXML private ListView<String> lstAdjuntos;
    @FXML private Button btnCrear;
    @FXML private ListView<Tickets> lstTickets;
    @FXML private TextField fldNota;
    @FXML private ComboBox<Estado> cbxEstados;
    @FXML private Text txtTicket;
    @FXML private Text txtTitulo;
    @FXML private Text txtEstado;
    @FXML private Text txtFechaCreacion;
    @FXML private Text txtCreador;
    @FXML private Button btnRegresar;
    @FXML private DatePicker fldDate;
    @FXML private MenuButton BotonMenu;
    @FXML private MenuItem Usuarios;
    @FXML private MenuItem itemRoles;
    @FXML private MenuItem itemTicket;
    @FXML private MenuItem itemDepartamento;
    @FXML private MenuItem itemDetallesTicket;
    @FXML private MenuItem itemFlujoDeTrabajo;
    @FXML private MenuItem itemHistorial;
    @FXML private MenuItem itemSalir;

    private List<Tickets> tickets = new ArrayList<>();
    private List<Departamento> departamentos = new ArrayList<>();
    private List<String> adjuntosTemporales = new ArrayList<>();

    private final String ARCHIVO_TICKETS = "tickets.dat";
    private final String ARCHIVO_DEPTOS = "departamentos.dat";

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDepartamentos();
        cargarTickets();

        cbxDepartamento.setItems(FXCollections.observableList(departamentos));
        cbxPrioridad.setItems(FXCollections.observableArrayList("Baja", "Media", "Alta"));
        cbxEstados.setItems(FXCollections.observableArrayList(Estado.values()));

        lstAdjuntos.setItems(FXCollections.observableList(adjuntosTemporales));
        lstTickets.setItems(FXCollections.observableList(tickets));

        lstTickets.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> mostrarDetallesTicket(newVal));
    }

    private void cargarTickets() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_TICKETS))) {
            tickets = (List<Tickets>) ois.readObject();
        } catch (Exception e) {
            tickets = new ArrayList<>();
        }
    }

    private void guardarTickets() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_TICKETS))) {
            oos.writeObject(tickets);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void cargarDepartamentos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_DEPTOS))) {
            departamentos = (List<Departamento>) ois.readObject();
        } catch (Exception e) {
            departamentos = new ArrayList<>();
        }
    }

    private void guardarDepartamentos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_DEPTOS))) {
            oos.writeObject(departamentos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Departamento buscarDepartamento(String nombre) {
        for (Departamento d : departamentos) {
            if (d.getNombre().equalsIgnoreCase(nombre)) {
                return d;
            }
        }
        return null;
    }

    @FXML
    private void adjuntarArchivo(ActionEvent ev) {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Todos los archivos", "*.*"));
        File f = fc.showOpenDialog(null);
        if (f != null) {
            adjuntosTemporales.add(f.getAbsolutePath());
            lstAdjuntos.refresh();
        }
    }

    @FXML
    private void crearTicket(ActionEvent ev) {
        String titulo = fldTitulo.getText().trim();
        String descripcion = txtDescripcion.getText().trim();
        Departamento departamento = cbxDepartamento.getValue();
        String prioridad = cbxPrioridad.getValue();
        String creadoPor = "admin";

        if (titulo.length() < 3 || descripcion.length() < 3) {
            mostrarAlerta("Error", "El título y la descripción deben tener al menos 3 caracteres.");
            return;
        }

        if (departamento == null) {
            mostrarAlerta("Error", "Debes seleccionar un departamento válido.");
            return;
        }

        if (prioridad == null) prioridad = "Media";

        Tickets nuevoTicket = new Tickets(titulo, descripcion, departamento.getNombre(), prioridad, creadoPor);

        for (String path : adjuntosTemporales) {
            nuevoTicket.agregarAdjunto(path);
        }

        Departamento depto = buscarDepartamento(departamento.getNombre());
        if (depto != null) {
            depto.agregarTicket(nuevoTicket);
            guardarDepartamentos();
        }

        tickets.add(nuevoTicket);
        guardarTickets();
        lstTickets.getItems().add(nuevoTicket);
        mostrarAlerta("Éxito", "Ticket creado correctamente.");
        limpiarFormulario();
    }

    private void limpiarFormulario() {
        fldTitulo.clear();
        txtDescripcion.clear();
        cbxDepartamento.getSelectionModel().clearSelection();
        cbxPrioridad.getSelectionModel().clearSelection();
        adjuntosTemporales.clear();
        lstAdjuntos.refresh();
    }

    @FXML
    private void tomarTicket(ActionEvent ev) {
        Tickets sel = lstTickets.getSelectionModel().getSelectedItem();
        if (sel == null || !sel.tomarTicket("TÉCNICO")) {
            mostrarAlerta("Error", "No puede tomar ese ticket.");
            return;
        }
        guardarTickets();
        lstTickets.refresh();
    }

    @FXML
    private void agregarNota(ActionEvent ev) {
        Tickets sel = lstTickets.getSelectionModel().getSelectedItem();
        String nota = fldNota.getText().trim();
        if (sel == null || nota.isEmpty()) return;
        sel.agregarNota("TÉCNICO", nota);
        guardarTickets();
        fldNota.clear();
    }

    @FXML
    private void cambiarEstado(ActionEvent ev) {
        Tickets sel = lstTickets.getSelectionModel().getSelectedItem();
        Estado nuevo = cbxEstados.getValue();
        if (sel == null || nuevo == null) return;
        sel.cambiarEstado(nuevo, "TÉCNICO");
        guardarTickets();
        lstTickets.refresh();
    }

    public void asignarTicket(Tickets ticket, String tecnico) {
        if (!ticket.getEstado().equals("Pendiente")) {
            mostrarAlerta("Error", "Este ticket ya está asignado.");
            return;
        }
        ticket.setTecnicoAsignado(tecnico);
        ticket.getEstado("En proceso");
        ticket.agregarHistorial("Asignado a " + tecnico);
    }

    public void cerrarTicket(Tickets ticket, String tecnico) {
        if (!tecnico.equals(ticket.getTecnicoAsignado())) {
            mostrarAlerta("Error", "Solo el técnico asignado puede cerrar este ticket.");
            return;
        }
        ticket.setEstado("Cerrado");
        ticket.agregarHistorial("Ticket cerrado por " + tecnico);
    }

    private void mostrarDetallesTicket(Tickets ticket) {
        if (ticket == null) return;
        txtTicket.setText("ID: " + ticket.getId());
        txtTitulo.setText(ticket.getTitulo());
        txtEstado.setText(ticket.getEstado());
        txtFechaCreacion.setText(ticket.getFechaCreacion().toString());
        txtCreador.setText(ticket.getCreadoPor());
    }

    private void mostrarAlerta(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }

    @FXML
    private void eventCrear(ActionEvent event) {
    }

    @FXML
    private void eventRegresar(ActionEvent event) {
    }

    @FXML
    private void eventUsuarios(ActionEvent event) {
    }

    @FXML
    private void eventRoles(ActionEvent event) {
    }

    @FXML
    private void eventTicket(ActionEvent event) {
    }

    @FXML
    private void eventDepartamento(ActionEvent event) {
    }

    @FXML
    private void eventDetalleTicket(ActionEvent event) {
    }

    @FXML
    private void itemFlujoDeTrabajo(ActionEvent event) {
    }

    @FXML
    private void eventHistorial(ActionEvent event) {
    }

    @FXML
    private void eventSallir(ActionEvent event) {
    }

    @FXML
    private void eventCambiarPantallla(ActionEvent event) {
    }
}
