package sistema_de_tickes;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author denil
 */
public class MenuUsuarioController implements Initializable {

    @FXML private MenuButton BotonMenu;
    @FXML private MenuItem itemTicket;
    @FXML private MenuItem itemDetallesTicket;
    @FXML private MenuItem itemFlujoDeTrabajo;
    @FXML private MenuItem itemSalir;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String rol = Sesion.getRol();
 if (!"Administrador".equals(rol)) {
            Usuarios.setDisable(true);
            itemRoles.setDisable(true);
            itemDepartamento.setDisable(true);
            itemSistema.setDisable(true);
        }

    }

    @FXML
    private void eventTicket(ActionEvent event) {
        cambiarPantalla("/Graficos/Ticket.fxml");
    }

    @FXML
    private void eventDetalleTicket(ActionEvent event) {
        cambiarPantalla("/Graficos/DetalleTicket.fxml");
    }

    @FXML
    private void itemFlujoDeTrabajo(ActionEvent event) {
        cambiarPantalla("/Graficos/FlujodeTrabajo.fxml");
    }

    @FXML
    private void eventSalir(ActionEvent event) {
        cambiarPantalla("/Graficos/Login.fxml");
    }

    private void cambiarPantalla(String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) BotonMenu.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            System.err.println("Error al cambiar de pantalla: " + rutaFXML);
            e.printStackTrace();
        }
    }
}