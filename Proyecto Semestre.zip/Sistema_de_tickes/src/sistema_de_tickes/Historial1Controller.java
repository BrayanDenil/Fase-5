package sistema_de_tickes;

import Modelos.HistorialCambios;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
/**
 * FXML Controller class
 *
 * @author denil
 */

public class Historial1Controller implements Initializable {

    private ObservableList<HistorialCambios> historialData = FXCollections.observableArrayList();

    @FXML private TableView<HistorialCambios> Tabla;
    @FXML private TableColumn<HistorialCambios, String> columUsuario;
    @FXML private TableColumn<HistorialCambios, LocalDateTime> columFehcaYHora;
    @FXML private TableColumn<HistorialCambios, String> columAccion;
    @FXML private TableColumn<HistorialCambios, String> columdetalles;
    @FXML private Button btnMostrar;
    @FXML private Button btnLimpiar;
    @FXML private Button btnRegresar;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        columUsuario.setCellValueFactory(new PropertyValueFactory<>("usuario"));
        columFehcaYHora.setCellValueFactory(new PropertyValueFactory<>("fechaHora"));
        columAccion.setCellValueFactory(new PropertyValueFactory<>("accion"));
        columdetalles.setCellValueFactory(new PropertyValueFactory<>("detalles"));
    }

    @FXML
    private void MostrarDatos(ActionEvent event) {
        historialData.clear(); // Limpiar antes de cargar
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        try (BufferedReader reader = new BufferedReader(new FileReader("historial.txt"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                try {
                    if (linea.length() < 22 || !linea.contains("Usuario: ")) continue;

                    LocalDateTime fechaHora = LocalDateTime.parse(linea.substring(1, 20), formatter);
                    String resto = linea.substring(22);
                    String[] partes = resto.split(" - ");

                    String usuario = partes[0].replace("Usuario: ", "").trim();
                    String accion = partes.length > 1 ? partes[1].replace("Acción: ", "").trim() : "";
                    String detalles = partes.length > 2 ? partes[2].replace("Detalles: ", "").trim() : "";

                    historialData.add(new HistorialCambios(usuario, fechaHora, accion, detalles));

                } catch (Exception e) {
                    System.err.println("Línea malformada: " + linea);
                }
            }
            Tabla.setItems(historialData);

        } catch (IOException e) {
            System.err.println("Error al leer el historial: " + e.getMessage());
        }
    }

    @FXML
    private void LimpiarDatos(ActionEvent event) {
        historialData.clear();
        Tabla.setItems(historialData);
    }

    @FXML
    private void Regresar(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/RolesYPermiso.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) btnRegresar.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}