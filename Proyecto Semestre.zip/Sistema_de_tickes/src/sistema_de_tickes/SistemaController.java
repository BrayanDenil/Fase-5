package sistema_de_tickes;

import Modelos.Configuracion_de_sistema;
import java.awt.event.MouseEvent;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.TimeZone;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author denil
 */
public class SistemaController implements Initializable {
   private final String ARCHIVO_CONFIG = "configuracion.dat";
   private Configuracion_de_sistema configuracion;
   private File archivoLogo;

   @FXML private TextField fldNombreEmpresa;
   @FXML private TextField fldVencimiento;
   @FXML private TextField fldNombre;
   @FXML private TextField fldNuevaPrioridad;
   @FXML private ImageView img;
   @FXML private ComboBox<String> boxIdioma;
   @FXML private ComboBox<String> boxHorario;
   @FXML private ComboBox<String> boxPrioridad;
   @FXML private Button btnRegistrar;
   @FXML private Button btnCancelar;
   @FXML private Button btnImagen;
   @FXML private Button btnRegresar;
   @FXML private ListView<String> lstPrioridades;
   @FXML private MenuButton BotonMenu;
   @FXML private MenuItem Usuarios, itemRoles, itemTicket, itemDepartamento,
                    itemDetallesTicket, itemFlujoDeTrabajo, itemHistorial, itemSalir;

   @FXML private Label txtNombre, txtLogo, txtIdioma, txtHoraio,
                        txtTicket, txtPrioridad, txtVencimiento;

   @Override
   public void initialize(URL location, ResourceBundle resources) {
       boxIdioma.setItems(FXCollections.observableArrayList("Español", "Inglés"));
       boxHorario.setItems(FXCollections.observableArrayList(TimeZone.getAvailableIDs()));
       lstPrioridades.setItems(FXCollections.observableArrayList());
       cargarConfiguracion();
   }

   private void cargarConfiguracion() {
       try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_CONFIG))) {
           configuracion = (Configuracion_de_sistema) ois.readObject();

           fldNombreEmpresa.setText(configuracion.getNombre());
           boxIdioma.setValue(configuracion.getIdioma());
           boxHorario.setValue(configuracion.getZonaHoraria());
           fldVencimiento.setText(String.valueOf(configuracion.getDiasVencimientoTicket()));
           lstPrioridades.setItems(FXCollections.observableArrayList(configuracion.getNivelesPrioridad()));

           // Mostrar imagen si es válida
           File file = new File(configuracion.getLogoPath());
           if (file.exists()) {
               img.setImage(new Image(file.toURI().toString()));
           }
       } catch (Exception e) {
           configuracion = null;
       }
   }

   @FXML
   private void seleccionarLogo() {
       FileChooser fc = new FileChooser();
       fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imágenes", "*.jpg", "*.png"));
       File file = fc.showOpenDialog(null);
       
       if (file != null) {
           if (file.length() > 2 * 1024 * 1024) { // Si el archivo es mayor a 2MB
               alerta("Error", "El archivo debe ser JPG o PNG y menor a 2MB.");
               return;
           }
           archivoLogo = file;
           img.setImage(new Image(file.toURI().toString()));
           btnRegistrar.setDisable(false); // Habilitar el botón "Registrar" si todo es correcto
       } else {
           alerta("Error", "Debe seleccionar una imagen de logo.");
       }
   }

   @FXML
   private void agregarPrioridad() {
       String prioridad = fldNuevaPrioridad.getText().trim();
       if (!prioridad.isEmpty() && !lstPrioridades.getItems().contains(prioridad)) {
           lstPrioridades.getItems().add(prioridad);
           fldNuevaPrioridad.clear();
       }
   }

   @FXML
   private void guardarConfiguracion() {
       String nombre = fldNombreEmpresa.getText().trim();
       String idioma = boxIdioma.getValue();
       String zona = boxHorario.getValue();
       String vencimientoTexto = fldVencimiento.getText().trim();
       List<String> prioridades = new ArrayList<>(lstPrioridades.getItems());

       // Validaciones
       if (nombre.length() < 3 || nombre.length() > 100) {
           alerta("Error", "El nombre de la empresa debe tener entre 3 y 100 caracteres.");
           return;
       }
       if (archivoLogo == null || !(archivoLogo.getName().endsWith(".jpg") || archivoLogo.getName().endsWith(".png"))) {
           alerta("Error", "Debe seleccionar un logo en formato JPG o PNG.");
           return;
       }
       if (idioma == null || zona == null) {
           alerta("Error", "Debe seleccionar idioma y zona horaria.");
           return;
       }
       int dias;
       try {
           dias = Integer.parseInt(vencimientoTexto);
       } catch (NumberFormatException e) {
           alerta("Error", "Ingrese un número válido para días de vencimiento.");
           return;
       }
       if (dias < 1 || dias > 365) {
           alerta("Error", "El tiempo de vencimiento debe estar entre 1 y 365 días.");
           return;
       }
       if (prioridades.size() < 3) {
           alerta("Error", "Debe definir al menos tres niveles de prioridad.");
           return;
       }

       configuracion = new Configuracion_de_sistema(nombre, archivoLogo.getAbsolutePath(), idioma, zona, dias, prioridades);

       try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_CONFIG))) {
           oos.writeObject(configuracion);
       } catch (IOException e) {
           alerta("Error", "No se pudo guardar la configuración.");
           return;
       }

       alerta("Éxito", "Configuración guardada correctamente.");
   }

   @FXML
   private void cancelarConfiguracion() {
       cargarConfiguracion();
       alerta("Cancelado", "Se descartaron los cambios.");
   }

   private void alerta(String titulo, String mensaje) {
       Alert alert = new Alert(Alert.AlertType.INFORMATION);
       alert.setTitle(titulo);
       alert.setHeaderText(null);
       alert.setContentText(mensaje);
       alert.showAndWait();
   }

   @FXML
   private void eventRegresar(ActionEvent event) {
       try {
           // Aquí podrías cargar una pantalla previa, por ejemplo, el menú principal
           FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Menu.fxml"));
           Parent root = loader.load();
           Scene scene = new Scene(root);
           Stage stage = (Stage) btnRegresar.getScene().getWindow();
           stage.setScene(scene);
           stage.show();
       } catch (IOException e) {
           alerta("Error", "No se pudo cargar el menú.");
       }
   }

   @FXML
   private void eventUsuarios(ActionEvent event) {
       try {
           FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Usuarios.fxml"));
           Parent root = loader.load();
           Scene scene = new Scene(root);
           Stage stage = (Stage) itemRoles.getScene().getWindow();
           stage.setScene(scene);
           stage.show();
       } catch (IOException e) {
           alerta("Error", "No se pudo cargar la vista de usuarios.");
       }
   }

   @FXML
   private void eventRoles(ActionEvent event) {
       try {
           FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Roles.fxml"));
           Parent root = loader.load();
           Scene scene = new Scene(root);
           Stage stage = (Stage) itemRoles.getScene().getWindow();
           stage.setScene(scene);
           stage.show();
       } catch (IOException e) {
           alerta("Error", "No se pudo cargar la vista de roles.");
       }
   }

   @FXML
   private void eventTicket(ActionEvent event) {
       try {
           FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Ticket.fxml"));
           Parent root = loader.load();
           Scene scene = new Scene(root);
           Stage stage = (Stage) itemTicket.getScene().getWindow();
           stage.setScene(scene);
           stage.show();
       } catch (IOException e) {
           alerta("Error", "No se pudo cargar la vista de tickets.");
       }
   }

   @FXML
   private void eventDepartamento(ActionEvent event) {
       try {
           FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Departamento.fxml"));
           Parent root = loader.load();
           Scene scene = new Scene(root);
           Stage stage = (Stage) itemDepartamento.getScene().getWindow();
           stage.setScene(scene);
           stage.show();
       } catch (IOException e) {
           alerta("Error", "No se pudo cargar la vista de departamentos.");
       }
   }

   @FXML
   private void eventDetalleTicket(ActionEvent event) {
       try {
           FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/DetallesTicket.fxml"));
           Parent root = loader.load();
           Scene scene = new Scene(root);
           Stage stage = (Stage) itemDetallesTicket.getScene().getWindow();
           stage.setScene(scene);
           stage.show();
       } catch (IOException e) {
           alerta("Error", "No se pudo cargar la vista de detalles de ticket.");
       }
   }

   @FXML
   private void itemFlujoDeTrabajo(ActionEvent event) {
       try {
           FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/FlujoDeTrabajo.fxml"));
           Parent root = loader.load();
           Scene scene = new Scene(root);
           Stage stage = (Stage) itemFlujoDeTrabajo.getScene().getWindow();
           stage.setScene(scene);
           stage.show();
       } catch (IOException e) {
           alerta("Error", "No se pudo cargar la vista de flujo de trabajo.");
       }
   }

   @FXML
   private void eventHistorial(ActionEvent event) {
       try {
           FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Historial.fxml"));
           Parent root = loader.load();
           Scene scene = new Scene(root);
           Stage stage = (Stage) itemHistorial.getScene().getWindow();
           stage.setScene(scene);
           stage.show();
       } catch (IOException e) {
           alerta("Error", "No se pudo cargar la vista de historial.");
       }
   }

   @FXML
   private void eventSalir(ActionEvent event) {
       // Implementa el cierre de la aplicación si es necesario
       System.exit(0);
   }
}




        
        
    

 

