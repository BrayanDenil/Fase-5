package sistema_de_tickes;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author denil
 */

public class MenuPrincipalController implements Initializable {

    @FXML private MenuButton BotonMenu;
    @FXML private MenuItem Usuarios;
    @FXML private MenuItem itemRoles;
    @FXML private MenuItem itemTicket;
    @FXML private MenuItem itemDepartamento;
    @FXML private MenuItem itemDetallesTicket;
    @FXML private MenuItem itemFlujoDeTrabajo;
    @FXML private MenuItem itemSistema;
    @FXML private MenuItem itemSalir;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    String rol = Sesion.getRol();
    if (!"Administrador".equals(rol)) {
        Usuarios.setDisable(true);
        itemRoles.setDisable(true);
        itemDepartamento.setDisable(true);
        itemSistema.setDisable(true);
    }
    }

   
    @FXML
    private void eventUsuarios(ActionEvent event) {
        cambiarPantalla("/Graficos/Usuarios.fxml");
    }

    @FXML
    private void eventRoles(ActionEvent event) {
        cambiarPantalla("/Graficos/RolesYPermisos.fxml");
    }

    @FXML
    private void eventTicket(ActionEvent event) {
        cambiarPantalla("/Graficos/Ticket.fxml");
    }

    @FXML
    private void eventDepartamento(ActionEvent event) {
        cambiarPantalla("/Graficos/Departamento.fxml");
    }

    @FXML
    private void eventDetalleTicket(ActionEvent event) {
        cambiarPantalla("/Graficos/DetalleTicket.fxml");
    }

    @FXML
    private void eventFlujoDeTrabajo(ActionEvent event) {
        cambiarPantalla("/Graficos/FlujodeTrabajo.fxml");
    }

    @FXML
    private void eventSistema(ActionEvent event) {
        cambiarPantalla("/Graficos/Sistema.fxml");
    }

    @FXML
    private void eventSalir(ActionEvent event) {
        cambiarPantalla("/Graficos/Login.fxml");
    }

    // Método reutilizable para cambiar de pantalla
    private void cambiarPantalla(String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) BotonMenu.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            System.err.println("No se pudo cargar la vista: " + rutaFXML);
            e.printStackTrace();
        }
    }
}
