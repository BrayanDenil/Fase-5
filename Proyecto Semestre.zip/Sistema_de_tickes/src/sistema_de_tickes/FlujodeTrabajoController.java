package sistema_de_tickes;

import Modelos.Flujo_De_Trabajo_Ticket;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.io.*;
import java.net.URL;
import java.time.LocalDate;
import java.util.*;

/**

 * @author denil
 */
public class FlujodeTrabajoController implements Initializable {

    private List<Flujo_De_Trabajo_Ticket> flujosDeTrabajo;
    private final String ARCHIVO_FLUJOS = "flujos_de_trabajo.dat";
    private final List<String> estadosDisponibles = Arrays.asList("Pendiente", "En proceso", "Resuelto", "Cerrado");

    // FXML Fields
    @FXML private TextField fldNombre, fldTransiciones, fldReglas, fldAcciones, fldCreador;
    @FXML private ComboBox<String> cbxEstados;
    @FXML private ListView<String> lstEstadosInvolucrados;
    @FXML private DatePicker dateFecha;
    @FXML private Button btnGuardar, btnEliminarFlujo, btnAgregarTransaccion, btnRegresar;
    @FXML private Label txtEstados, txtTransiciones, txtReglas, txtAcciones, txtCreador, txtFecha;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarFlujosDeTrabajo();
        cbxEstados.getItems().addAll(estadosDisponibles);
    }

    // Cargar flujos desde archivo
    private void cargarFlujosDeTrabajo() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_FLUJOS))) {
            flujosDeTrabajo = (List<Flujo_De_Trabajo_Ticket>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            flujosDeTrabajo = new ArrayList<>();
        }
    }

    // Guardar flujos al archivo
    private void guardarFlujosDeTrabajo() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_FLUJOS))) {
            oos.writeObject(flujosDeTrabajo);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Guardar nuevo flujo
    @FXML
    private void guardarFlujoDeTrabajo(ActionEvent event) {
        String nombreFlujo = fldNombre.getText().trim();
        if (nombreFlujo.isEmpty()) {
            mostrarAlerta("Error", "El nombre del flujo no puede estar vacío.");
            return;
        }

        if (flujoYaExiste(nombreFlujo)) {
            mostrarAlerta("Error", "Ya existe un flujo con ese nombre.");
            return;
        }

        List<String> estadosSeleccionados = new ArrayList<>(lstEstadosInvolucrados.getItems());
        if (estadosSeleccionados.isEmpty()) {
            mostrarAlerta("Error", "Debe agregar al menos un estado involucrado.");
            return;
        }

        // Crear mapas con reglas, transiciones y acciones
        Map<String, List<String>> transicionesPermitidas = new HashMap<>();
        Map<String, String> reglasTransicion = new HashMap<>();
        Map<String, String> accionesAutomaticas = new HashMap<>();

        for (String estado : estadosSeleccionados) {
            List<String> transiciones = Arrays.stream(fldTransiciones.getText().split(","))
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .toList();

            transicionesPermitidas.put(estado, transiciones);
            reglasTransicion.put(estado, fldReglas.getText().trim());
            accionesAutomaticas.put(estado, fldAcciones.getText().trim());
        }

        Flujo_De_Trabajo_Ticket nuevoFlujo = new Flujo_De_Trabajo_Ticket(
                nombreFlujo,
                estadosSeleccionados,
                transicionesPermitidas,
                reglasTransicion,
                accionesAutomaticas
        );

        flujosDeTrabajo.add(nuevoFlujo);
        guardarFlujosDeTrabajo();
        mostrarAlerta("Éxito", "Flujo de trabajo guardado correctamente.");
        limpiarCampos();
    }

    
    @FXML
    private void eliminarFlujoDeTrabajo(ActionEvent event) {
        String nombreFlujo = fldNombre.getText().trim();
        Optional<Flujo_De_Trabajo_Ticket> flujo = flujosDeTrabajo.stream()
                .filter(f -> f.getNombre().equalsIgnoreCase(nombreFlujo))
                .findFirst();

        if (flujo.isPresent()) {
            flujosDeTrabajo.remove(flujo.get());
            guardarFlujosDeTrabajo();
            mostrarAlerta("Éxito", "Flujo de trabajo eliminado correctamente.");
            limpiarCampos();
        } else {
            mostrarAlerta("Error", "Flujo de trabajo no encontrado.");
        }
    }

   
    @FXML
    private void agregarEstadoALista(ActionEvent event) {
        String estadoSeleccionado = cbxEstados.getSelectionModel().getSelectedItem();
        if (estadoSeleccionado != null && !lstEstadosInvolucrados.getItems().contains(estadoSeleccionado)) {
            lstEstadosInvolucrados.getItems().add(estadoSeleccionado);
        }
    }

 
    @FXML
    private void eventRegresar(ActionEvent event) {
        // Aquí puedes cargar otra escena o cerrar la ventana actual
        mostrarAlerta("Regreso", "Funcionalidad de regreso aún no implementada.");
    }

    
    private boolean flujoYaExiste(String nombre) {
        return flujosDeTrabajo.stream().anyMatch(f -> f.getNombre().equalsIgnoreCase(nombre));
    }

    
    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void limpiarCampos() {
        fldNombre.clear();
        fldTransiciones.clear();
        fldReglas.clear();
        fldAcciones.clear();
        lstEstadosInvolucrados.getItems().clear();
        cbxEstados.getSelectionModel().clearSelection();
        fldCreador.clear();
        dateFecha.setValue(null);
    }
}