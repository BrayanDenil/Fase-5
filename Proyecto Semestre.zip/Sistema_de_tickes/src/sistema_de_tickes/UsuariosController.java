package sistema_de_tickes;

import Modelos.Persona;
import Modelos.Usuario;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author denil
 */


public class UsuariosController implements Initializable {

    private List<Persona> usuarios = new ArrayList<>();
    private Usuario usuarioRegistrado;

    @FXML private Pane txtArea;
    @FXML private TextField fldNombre, fldApellido, fldCorreo, fldContraseña, fldTelefono, fldArea;
    @FXML private DatePicker fldIngreso;
    @FXML private ComboBox<String> cbxRol;
    @FXML private ComboBox<String> cbxDepartamento;
    @FXML private Label txtDepartamento;
    @FXML private Button btnRegistrar, btnLimpiar, btnRegresar;
    @FXML private Label txtUsuario;
    @FXML private Label txtNombre;
    @FXML private Label txtContraseña;
    @FXML private Label txtRol;
    @FXML private TextField fldCodigoUsuario;
    @FXML private Label txtTelefono;
    @FXML private Label txtRol11;
    @FXML private Label txtIngreso;
    @FXML private Label txtApellido;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cbxRol.setItems(FXCollections.observableArrayList("Administrador", "Técnico", "Usuario"));
        cbxDepartamento.setItems(FXCollections.observableArrayList("Soporte", "Desarrollo", "Infraestructura"));

        // Ocultar departamento inicialmente
        cbxDepartamento.setVisible(false);
        txtDepartamento.setVisible(false);

        cbxRol.setOnAction(e -> {
            String rolSeleccionado = cbxRol.getValue();
            boolean esTecnico = "Técnico".equals(rolSeleccionado);
            cbxDepartamento.setVisible(esTecnico);
            txtDepartamento.setVisible(esTecnico);
        });
    }

    @FXML
    private void eventRegresar(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Sistema.fxml"));
            Scene scene = new Scene(loader.load());
            Stage stage = (Stage) btnRegresar.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void evenRegistrar(ActionEvent event) {
        String usuario = fldCodigoUsuario.getText().trim();
        String nombre = fldNombre.getText().trim();
        String apellido = fldApellido.getText().trim();
        String correo = fldCorreo.getText().trim();
        String contraseña = fldContraseña.getText().trim();
        String telefono = fldTelefono.getText().trim();
        String rol = cbxRol.getValue();
        String area = fldArea.getText().trim();
        String ingreso = fldIngreso.getValue() != null ? fldIngreso.getValue().toString() : "";
        String departamento = cbxDepartamento.getValue() != null ? cbxDepartamento.getValue() : "";

        // Validaciones
        if (!validarCampos(usuario, nombre, apellido, correo, contraseña, telefono, rol, ingreso)) {
            mostrarAlerta("Campos inválidos", "Completa correctamente todos los campos requeridos.", Alert.AlertType.WARNING);
            return;
        }

        // Validación de correo
        if (!validarCorreo(correo)) {
            mostrarAlerta("Correo inválido", "El correo electrónico no tiene un formato válido.", Alert.AlertType.WARNING);
            return;
        }

        // Validación de contraseña
        if (!validarContraseña(contraseña)) {
            mostrarAlerta("Contraseña insegura", "Debe tener al menos 8 caracteres, una mayúscula, un número y un carácter especial.", Alert.AlertType.WARNING);
            return;
        }

        // Validación de teléfono
        if (telefono.length() < 7) {
            mostrarAlerta("Teléfono inválido", "El número de teléfono debe tener al menos 7 dígitos.", Alert.AlertType.WARNING);
            return;
        }

        // Validación específica para técnicos
        if ("Técnico".equals(rol) && departamento.isEmpty()) {
            mostrarAlerta("Departamento requerido", "Debes seleccionar un departamento si el rol es Técnico.", Alert.AlertType.WARNING);
            return;
        }

        // Verificación de unicidad (correo y usuario)
        if (existeUsuario(correo, usuario)) {
            return;
        }

        // Crear y guardar usuario
        Persona nuevoUsuario = new Persona(usuario, nombre, apellido, correo, contraseña, telefono, rol, area, ingreso);
        usuarios.add(nuevoUsuario);
        registrarAccion(usuario, "Registro", "Rol: " + rol + (rol.equals("Técnico") ? ", Departamento: " + departamento : ""));
        mostrarAlerta("Éxito", "Usuario registrado correctamente.", Alert.AlertType.INFORMATION);
        limpiarCampos();
    }

    @FXML
    private void eventLimpiar(ActionEvent event) {
        limpiarCampos();
    }

    private void limpiarCampos() {
        fldCodigoUsuario.clear();
        fldNombre.clear();
        fldApellido.clear();
        fldCorreo.clear();
        fldContraseña.clear();
        fldTelefono.clear();
        fldArea.clear();
        fldIngreso.setValue(null);
        cbxRol.setValue(null);
        cbxDepartamento.setValue(null);
        cbxDepartamento.setVisible(false);
        txtDepartamento.setVisible(false);
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    public static void registrarAccion(String usuario, String accion, String detalles) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("historial_usuarios.txt", true))) {
            String fechaHora = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            String linea = String.format("[%s] Usuario: %s - Acción: %s - Detalles: %s", fechaHora, usuario, accion, detalles);
            writer.println(linea);
        } catch (Exception e) {
            System.err.println("Error al registrar historial: " + e.getMessage());
        }
    }

    private boolean validarCampos(String usuario, String nombre, String apellido, String correo, String contraseña, String telefono, String rol, String ingreso) {
        return !(usuario.length() < 5 || usuario.length() > 30 ||
            nombre.length() < 3 || nombre.length() > 100 ||
            apellido.isEmpty() || correo.isEmpty() || contraseña.isEmpty() ||
            telefono.isEmpty() || rol.isEmpty() || ingreso.isEmpty());
    }

    private boolean validarCorreo(String correo) {
        return correo.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    }

    private boolean validarContraseña(String contraseña) {
        return contraseña.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$");
    }

    private boolean existeUsuario(String correo, String usuario) {
        for (Persona p : usuarios) {
            if (p.getCorreo().equalsIgnoreCase(correo)) {
                mostrarAlerta("Correo duplicado", "Este correo ya está registrado.", Alert.AlertType.ERROR);
                return true;
            }
            if (p.getCodigoUsuario().equalsIgnoreCase(usuario)) {
                mostrarAlerta("Usuario duplicado", "Este nombre de usuario ya existe.", Alert.AlertType.ERROR);
                return true;
            }
        }
        return false;
    }

    public Usuario getUsuario() {
        return usuarioRegistrado;
    }
}