package sistema_de_tickes;

import java.net.URL;
import Modelos.Tickets;
import Modelos.Estado;

import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
/**
 * FXML Controller class
 *
 * @author denil
 */

public class Estado_de_tikcetController implements Initializable {

    @FXML private TextField fldNombre;
    @FXML private ComboBox<Estado> fldEstados;
    @FXML private TextField fldDescripcion;
    @FXML private CheckBox ChecBx;
    @FXML private Button btnGuardar;
    @FXML private Button btnCancelar;
    @FXML private Button btnEliminar;
    @FXML private MenuButton Menu;
    @FXML private MenuItem mbRegresar;

    private Tickets ticketSeleccionado;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Cargar los estados disponibles en el ComboBox
        fldEstados.getItems().setAll(Estado.values());
    }

    // Método para establecer el ticket a modificar
    public void setTicketSeleccionado(Tickets ticket) {
        this.ticketSeleccionado = ticket;
        // Cargar el estado actual en el ComboBox si existe
        fldEstados.setValue(ticket.getEstado());
        fldNombre.setText("Ticket #" + ticket.getId());
    }

    // Acción para cambiar el estado del ticket
    @FXML
    private void cambiarEstado(ActionEvent event) {
        Estado nuevoEstado = fldEstados.getValue();
        String comentario = fldDescripcion.getText().trim();

        if (nuevoEstado == null) {
            mostrarNotificacion("Selecciona un nuevo estado.", Alert.AlertType.WARNING);
            return;
        }

        if (!nuevoEstado.equals(ticketSeleccionado.getEstado())) {
            ticketSeleccionado.cambiarEstado(nuevoEstado, "Cambio de estado: " + comentario);
            mostrarNotificacion("El estado del ticket ha sido cambiado a: " + nuevoEstado, Alert.AlertType.INFORMATION);
        } else {
            mostrarNotificacion("El estado seleccionado es el mismo que el actual.", Alert.AlertType.WARNING);
        }
    }

    // Limpiar campos si se cancela la operación
    @FXML
    private void cancelarCambio(ActionEvent event) {
        fldNombre.clear();
        fldDescripcion.clear();
        fldEstados.setValue(null);
        ChecBx.setSelected(false);
    }

    // Simula la eliminación del estado
    @FXML
    private void eliminarEstado(ActionEvent event) {
        // Aquí se puede implementar lógica real de eliminación si se requiere
        mostrarNotificacion("El estado seleccionado ha sido eliminado (simulación).", Alert.AlertType.INFORMATION);
    }

    // Acción para regresar al menú anterior (debe implementarse según el contexto)
    @FXML
    private void regresar(ActionEvent event) {
        // Ejemplo: cerrar ventana o cargar otra escena
        mostrarNotificacion("Volviendo al menú anterior...", Alert.AlertType.INFORMATION);
    }

    // Simulación de guardar un nuevo estado (realmente no se usa si solo editas tickets)
    @FXML
    private void guardarEstado(ActionEvent event) {
        String nombre = fldNombre.getText().trim();
        String descripcion = fldDescripcion.getText().trim();
        boolean estadoFinal = ChecBx.isSelected();

        if (nombre.isEmpty()) {
            mostrarNotificacion("El nombre del estado no puede estar vacío.", Alert.AlertType.ERROR);
            return;
        }

        // Aquí iría lógica para guardar el estado si es parte del sistema
        mostrarNotificacion("Estado guardado correctamente (simulado).", Alert.AlertType.INFORMATION);
    }

    // Método para mostrar alertas
    private void mostrarNotificacion(String mensaje, Alert.AlertType tipo) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle("Notificación");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}