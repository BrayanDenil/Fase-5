
package sistema_de_tickes;

/**
 *
 * @author denil
 */
public class Sesion {
     private static String usuario;
    private static String rol;

    public static void iniciarSesion(String user, String role) {
        usuario = user;
        rol = role;
    }

    public static String getUsuario() {
        return usuario;
    }

    public static String getRol() {
        return rol;
    }

    public static void cerrarSesion() {
        usuario = null;
        rol = null;
    }
}

