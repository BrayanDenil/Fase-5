package sistema_de_tickes;

import Modelos.Departamento;
import Modelos.Tecnico;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author denil
 */
public class DepartamentoController implements Initializable {

    @FXML private Button btlRegresar;
    @FXML private Label txtDepartamento;
    @FXML private TextField fldDepartamento;
    @FXML private Label txtTecnico;
    @FXML private Label txtCracion;
    @FXML private Label txtCierre;
    @FXML private Button btnAgregar;
    @FXML private Button btnEliminar;
    @FXML private DatePicker dateCreacion;
    @FXML private DatePicker dateCierre;
    @FXML private Label txtDescripcion;
    @FXML private TextField fldDescripcion;
    
    @FXML private ListView<Tecnico> lstTecnicos;
    @FXML private ListView<Departamento> lstDepartamentos;

    private List<Departamento> departamentos;
    private List<Tecnico> tecnicosDisponibles;
    
    private final String ARCHIVO_DEPARTAMENTOS = "departamentos.dat";
    private final String ARCHIVO_TECNICOS = "tecnicos.dat";
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarDepartamentos();
        cargarTecnicos();
    }

    private void cargarDepartamentos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_DEPARTAMENTOS))) {
            departamentos = (List<Departamento>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            departamentos = new ArrayList<>();
        }
        lstDepartamentos.setItems(FXCollections.observableList(departamentos));
    }

    private void guardarDepartamentos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_DEPARTAMENTOS))) {
            oos.writeObject(departamentos);
        } catch (IOException e) {
            mostrarAlerta("Error", "Hubo un error al guardar los departamentos.");
        }
    }

    private void cargarTecnicos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_TECNICOS))) {
            tecnicosDisponibles = (List<Tecnico>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            tecnicosDisponibles = new ArrayList<>();
        }
        lstTecnicos.setItems(FXCollections.observableList(tecnicosDisponibles));
        lstTecnicos.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    @FXML
    private void Agregar(ActionEvent event) {
        String nombre = fldDepartamento.getText().trim();
        String descripcion = fldDescripcion.getText().trim();
        List<Tecnico> tecnicosSeleccionados = lstTecnicos.getSelectionModel().getSelectedItems();

      
        if (!esNombreValido(nombre)) {
            mostrarAlerta("Error", "El nombre del departamento debe tener entre 3 y 50 caracteres.");
            return;
        }

     
        if (existeDepartamento(nombre)) {
            mostrarAlerta("Error", "Ya existe un departamento con ese nombre.");
            return;
        }

       
        if (tecnicosSeleccionados.isEmpty()) {
            mostrarAlerta("Error", "Debes seleccionar al menos un técnico.");
            return;
        }

       
        if (!esFechaValida(dateCreacion.getValue(), dateCierre.getValue())) {
            mostrarAlerta("Error", "La fecha de cierre no puede ser anterior a la fecha de creación.");
            return;
        }

       
        Departamento nuevo = new Departamento(nombre, descripcion);
        nuevo.setTecnicoAsignados(new ArrayList<>(tecnicosSeleccionados));

        departamentos.add(nuevo);
        guardarDepartamentos();

        mostrarAlerta("Éxito", "Departamento registrado exitosamente.");
        limpiarCampos();
    }

    @FXML
    private void Eliminar(ActionEvent event) {
        String nombre = fldDepartamento.getText().trim();
        Optional<Departamento> dep = departamentos.stream()
            .filter(d -> d.getNombre().equalsIgnoreCase(nombre))
            .findFirst();

        if (dep.isPresent()) {
            Departamento departamento = dep.get();

            
            if ((departamento.getColaAtencion() == null || departamento.getColaAtencion().getTickets() == null) ||
            !departamento.getColaAtencion().getTickets().isEmpty()) {
                mostrarAlerta("Advertencia", "No se puede eliminar un departamento con tickets activos.");
            } else {
                
                // Mostrar diálogo de confirmación
                Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
                confirmacion.setTitle("Confirmar eliminación");
                confirmacion.setHeaderText("¿Estás seguro de que deseas eliminar este departamento?");
                Optional<ButtonType> result = confirmacion.showAndWait();
                
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    departamentos.remove(departamento);
                    guardarDepartamentos();
                    mostrarAlerta("Éxito", "Departamento eliminado.");
                }
            }
        } else {
            mostrarAlerta("Error", "Departamento no encontrado.");
        }

        limpiarCampos();
    }

    private boolean esNombreValido(String nombre) {
        return nombre.length() >= 3 && nombre.length() <= 50;
    }

    private boolean existeDepartamento(String nombre) {
        return departamentos.stream().anyMatch(d -> d.getNombre().equalsIgnoreCase(nombre));
    }

    private boolean esFechaValida(java.time.LocalDate fechaCreacion, java.time.LocalDate fechaCierre) {
        return fechaCierre == null || !fechaCierre.isBefore(fechaCreacion);
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void limpiarCampos() {
        fldDepartamento.clear();
        fldDescripcion.clear();
        lstTecnicos.getSelectionModel().clearSelection();
        dateCreacion.setValue(null);
        dateCierre.setValue(null);
    }

    @FXML
    private void seleccionarDepartamento(ActionEvent event) {
        Departamento departamentoSeleccionado = lstDepartamentos.getSelectionModel().getSelectedItem();
        if (departamentoSeleccionado != null) {
            fldDepartamento.setText(departamentoSeleccionado.getNombre());
            fldDescripcion.setText(departamentoSeleccionado.getDescripcion());
            lstTecnicos.getSelectionModel().clearSelection();
        }
    }

    @FXML
    private void eventRegresar(ActionEvent event) {
        try {
            guardarDepartamentos();  // Asegúrate de guardar antes de regresar
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Sistema.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) btlRegresar.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
}