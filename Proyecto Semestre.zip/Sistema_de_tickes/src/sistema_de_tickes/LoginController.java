package sistema_de_tickes;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
/**
 * FXML Controller class
 *
 * @author denil
 */

public class LoginController implements Initializable {

    private final Autenticacion autenticar = new Autenticacion();

    @FXML private Button btnSalir;
    @FXML private Button btnIngresar;
    @FXML private PasswordField passContraseña;
    @FXML private TextField fldUsuario;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Usuarios predefinidos
        autenticar.agregarUsuario("admin1", "admin123", "Administrador");
        autenticar.agregarUsuario("tecnico1", "123", "Tecnico");
        autenticar.agregarUsuario("usuario1", "1234", "Usuario");
    }

    @FXML
    private void eventSalir(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmación");
        alert.setHeaderText("¿Estás seguro de que quieres salir?");
        alert.setContentText("Se cerrará la aplicación.");

        if (alert.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            System.exit(0);
        }
    }

    @FXML
    private void eventIngresar(ActionEvent event) {
        String usuario = fldUsuario.getText().trim();
        String contraseña = passContraseña.getText();

        if (usuario.isEmpty() || contraseña.isEmpty()) {
            mostrarMensaje(Alert.AlertType.WARNING, "Campos Vacíos", "Por favor, completa todos los campos.");
            return;
        }

        String rol = autenticar.validarCredenciales(usuario, contraseña);
        Sesion.iniciarSesion(usuario, rol);

        if (rol != null) {
            mostrarMensaje(Alert.AlertType.INFORMATION, "Bienvenido", "Hola " + usuario + ", has iniciado sesión como " + rol + ".");
            navegarSegunRol(rol);
        } else {
            mostrarMensaje(Alert.AlertType.ERROR, "Error de Inicio de Sesión", "Usuario o contraseña incorrectos.");
        }
    }

    private void mostrarMensaje(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void navegarSegunRol(String rol) {
        String rutaFXML;
        switch (rol) {
            case "Administrador":
                rutaFXML = "/Graficos/Sistema.fxml";
                break;
            case "Tecnico":
                rutaFXML = "/Graficos/Menu Principal.fxml";
                break;
            case "Usuario":
                rutaFXML = "/Graficos/MenuUsuario.fxml";
                break;
            default:
                mostrarMensaje(Alert.AlertType.ERROR, "Rol Desconocido", "No se pudo reconocer el rol.");
                return;
        }

        Stage stage = (Stage) btnIngresar.getScene().getWindow();
        cargarFXML(rutaFXML, stage);
    }

    private void cargarFXML(String ruta, Stage stage) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(ruta));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            mostrarMensaje(Alert.AlertType.ERROR, "Error", "No se pudo cargar la ventana: " + ruta);
            e.printStackTrace();
        }
    }
    
}
