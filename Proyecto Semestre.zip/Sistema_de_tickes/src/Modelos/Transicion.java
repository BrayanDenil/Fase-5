package Modelos;

/**
 * Autor: denil
 */
public class Transicion {
    private Estado desde; 
    private Estado hacia;  
    private String regla;  

    
    public Transicion(Estado desde, Estado hacia, String regla) {
        this.desde = desde;
        this.hacia = hacia;
        this.regla = regla;
    }

    public Estado getDesde() {
        return desde;
    }

    public Estado getHacia() {
        return hacia;
    }

    public String getRegla() {
        return regla;
    }

    
    @Override
    public String toString() {
        return "Transición desde " + desde + " hacia " + hacia + " con la regla: " + regla;
    }
}

