package Modelos;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Modelo para representar un ticket de soporte técnico.
 * Autor: denil
 */
public class Tickets implements Serializable {
    private String id;
    private String titulo;
    private String descripcion;
    private String departamentoAsignado;
    private String prioridad;
    private List<String> adjuntos;
    private Estado estado;
    private String creadoPor;
    private LocalDate fechaCreacion;
    private String tecnicoAsignado;
    private List<String> historial;
    private List<String> notas;

    public Tickets(String titulo, String descripcion, String departamentoAsignado,
                   String prioridad, String creadoPor) {
        this.id = UUID.randomUUID().toString();
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.departamentoAsignado = departamentoAsignado;
        this.prioridad = prioridad;
        this.creadoPor = creadoPor;
        this.estado = Estado.PENDIENTE;
        this.fechaCreacion = LocalDate.now();
        this.adjuntos = new ArrayList<>();
        this.historial = new ArrayList<>();
        this.notas = new ArrayList<>();
        historial.add("Ticket creado por " + creadoPor + " el " + fechaCreacion);
    }

    public void agregarAdjunto(String path) {
        adjuntos.add(path);
    }

    public void agregarNota(String usuario, String nota) {
        notas.add(usuario + ": " + nota);
        historial.add("Nota agregada por " + usuario);
    }

    public void cambiarEstado(Estado nuevoEstado, String comentario) {
    this.estado = nuevoEstado;
    if (comentario != null && !comentario.isEmpty()) {
        agregarNota("Sistema", comentario);
    }
}

    public boolean tomarTicket(String tecnico) {
        if (estado == Estado.PENDIENTE) {
            this.estado = Estado.EN_PROCESO;
            this.tecnicoAsignado = tecnico;
            historial.add("Ticket tomado por " + tecnico);
            return true;
        }
        return false;
    }

    public void agregarHistorial(String evento) {
        historial.add(evento);
    }

    // Getters y Setters

    public String getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDepartamentoAsignado() {
        return departamentoAsignado;
    }

    public void setDepartamentoAsignado(String departamentoAsignado) {
        this.departamentoAsignado = departamentoAsignado;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public List<String> getAdjuntos() {
        return adjuntos;
    }

    public String getCreadoPor() {
        return creadoPor;
    }

    public LocalDate getFechaCreacion() {
        return fechaCreacion;
    }

    public List<String> getHistorial() {
        return historial;
    }

    public List<String> getNotas() {
        return notas;
    }

    public String getTecnicoAsignado() {
        return tecnicoAsignado;
    }

    public Estado getEstado() {
        return estado;
        
        
   
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setAdjuntos(List<String> adjuntos) {
        this.adjuntos = adjuntos;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public void setCreadoPor(String creadoPor) {
        this.creadoPor = creadoPor;
    }

    public void setFechaCreacion(LocalDate fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public void setTecnicoAsignado(String tecnicoAsignado) {
        this.tecnicoAsignado = tecnicoAsignado;
    }

    public void setHistorial(List<String> historial) {
        this.historial = historial;
    }

    public void setNotas(List<String> notas) {
        this.notas = notas;
    }

    @Override
    public String toString() {
        return "Tickets{" + "id=" + id + ", "
                + "titulo=" + titulo + ", "
                + "descripcion=" + descripcion + ","
                + " departamentoAsignado=" + departamentoAsignado + ","
                + " prioridad=" + prioridad + ", adjuntos=" + adjuntos + ", "
                + "estado=" + estado + ", creadoPor=" + creadoPor + ", "
                + "fechaCreacion=" + fechaCreacion + ", tecnicoAsignado=" + tecnicoAsignado + ","
                + " historial=" + historial + ", notas=" + notas + '}';
    }
    
    
}