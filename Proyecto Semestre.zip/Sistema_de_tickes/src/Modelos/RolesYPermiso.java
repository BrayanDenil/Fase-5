package Modelos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * Autor: denil
 */
public class RolesYPermiso implements Serializable {
    private String nombre;
    private String descripcion;
    private List<Permiso> permisos;

    public RolesYPermiso(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.permisos = new ArrayList<>();
    }

    // Getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public List<Permiso> getPermisos() {
        return new ArrayList<>(permisos); // Retorna una copia para proteger la lista original
    }

    public void setPermisos(List<Permiso> permisos) {
        this.permisos = (permisos != null) ? permisos : new ArrayList<>();
    }

    // Métodos para gestionar permisos
    public void agregarPermiso(Permiso permiso) {
        if (permiso != null && !permisos.contains(permiso)) {
            permisos.add(permiso);
        }
    }

    public void quitarPermiso(Permiso permiso) {
        permisos.remove(permiso);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Rol: " + nombre + " - " + descripcion + "\nPermisos: ");
        if (permisos.isEmpty()) {
            sb.append("Ninguno");
        } else {
            for (Permiso p : permisos) {
                sb.append(p.getNombre()).append(", ");
            }
            sb.setLength(sb.length() - 2); // Eliminar la última coma
        }
        return sb.toString();
    }
    
    
}