package Modelos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author denil
 */
public class Gestion_De_Tickets {

    private final List<Tickets> tickets;

    public Gestion_De_Tickets(List<Tickets> ticketsIniciales) {

        this.tickets = (ticketsIniciales != null) ? ticketsIniciales : new ArrayList<>();
    }

    public void crearTicket(String descripcion, Usuario usuarioSolicitante) {
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException("La descripción no puede estar vacía.");
        }
        if (usuarioSolicitante == null) {
            throw new IllegalArgumentException("El usuario solicitante no puede ser nulo.");
        }

        int nuevoId = tickets.size() + 1;
        Tickets nuevoTicket = new Tickets(nuevoId, descripcion, usuarioSolicitante);
        tickets.add(nuevoTicket);
    }

    public List<Tickets> obtenerTodosLosTickets() {
        return new ArrayList<>(tickets); 
    }

    public List<Tickets> obtenerTicketsPendientes() {
        List<Tickets> pendientes = new ArrayList<>();
        for (Tickets ticket : tickets) {
            if ("Pendiente".equalsIgnoreCase(ticket.getEstado())) {
                pendientes.add(ticket);
            }
        }
        return pendientes;
    }

    public void cambiarEstadoTicket(int ticketId, String nuevoEstado) {
        if (nuevoEstado == null || nuevoEstado.trim().isEmpty()) {
            throw new IllegalArgumentException("El nuevo estado no puede ser nulo o vacío.");
        }

        Tickets ticket = buscarTicketPorId(ticketId);
        if (ticket != null) {
            ticket.setEstado(nuevoEstado);
        } else {
            throw new IllegalArgumentException("Ticket no encontrado con ID: " + ticketId);
        }
    }

    public void agregarNota(int ticketId, String nota) {
        if (nota == null || nota.trim().isEmpty()) {
            throw new IllegalArgumentException("La nota no puede ser nula o vacía.");
        }

        Tickets ticket = buscarTicketPorId(ticketId);
        if (ticket != null) {
            ticket.agregarNota(nota);
        } else {
            throw new IllegalArgumentException("Ticket no encontrado con ID: " + ticketId);
        }
    }

    private Tickets buscarTicketPorId(int id) {
        for (Tickets ticket : tickets) {
            if (ticket.getId() == id) {
                return ticket;
            }
        }
        return null;
    }
}