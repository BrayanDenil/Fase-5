package Modelos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author denil
 */
public class Cambiar_estado_Ticket {

    public enum Estado {
        PENDIENTE, EN_PROCESO, ESCALADO, CERRADO
    }

    private String id;
    private Estado estado;
    private String descripcion;
    private String departamento;
    private List<String> historialEstados;

    public Cambiar_estado_Ticket(String id, String descripcion, String departamento) {
        this.id = id;
        this.descripcion = descripcion;
        this.departamento = departamento;
        this.estado = Estado.PENDIENTE;
        this.historialEstados = new ArrayList<>();
    }

  
    public void cambiarEstado(Estado nuevoEstado, String comentario) {
        this.estado = nuevoEstado;
        historialEstados.add("Estado cambiado a " + nuevoEstado + ": " + comentario);
    }

    public Estado getEstado() {
        return estado;
    }

    public List<String> getHistorialEstados() {
        return historialEstados;
        
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    @Override
    public String toString() {
        return "Cambiar_estado_Ticket{" + "id=" + id + ", estado=" + estado + ", descripcion=" + descripcion + ", departamento=" + departamento + ", historialEstados=" + historialEstados + '}';
    }
}