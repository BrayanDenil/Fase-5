package Modelos;

/**
 * 
 * 
 * @author denil
 */
public enum Estado {
    PENDIENTE,
    EN_PROCESO,
    RESUELTO,
    CERRADO,
    CANCELADO;


    public boolean esFinal() {
        return this == RESUELTO || this == CERRADO || this == CANCELADO;
    }

    @Override
    public String toString() {
        return "Estado{" + '}';
    }

    
}
    
    

