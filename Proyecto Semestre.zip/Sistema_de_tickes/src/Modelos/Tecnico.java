package Modelos;

/**
 * 
 * Autor: denil
 */
public class Tecnico extends Persona {

    public Tecnico(String codigoUsuario, String nombre, String apellido, String correo,
                   String contraseña, String telefono, String rol, String area, String ingresoStr) {
        super(codigoUsuario, nombre, apellido, correo, contraseña, telefono, rol, area, ingresoStr);
    }

    @Override
    public String toString() {
        return getNombre() + " " + getApellido();
    }
}